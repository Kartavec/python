package lesson5;

public class CreateEmployee {
    public static void main(String[] args) {

        Employee[] backOffice = new Employee[5];
        backOffice[0] = new Employee("Иванов И.И.", "Юрист", "ivanov@mail.ru", "8-925-999-99-99", 50000.00, 36);
        backOffice[1] = new Employee("Суворова Д.И.", "Бухгалтер", "suvorova@mail.ru", "8-925-888-88-88", 40000.00, 29);
        backOffice[2] = new Employee("Анисимова А.В.", "HR", "anisimova@mail.ru", "8-925-777-77-77", 30000.00, 32);
        backOffice[3] = new Employee("Гаврилова П.А.", "Кадровик", "gavrilova@mail.ru", "8-925-666-66-66", 80000.00, 41);
        backOffice[4] = new Employee("Петрова П.Е.", "Главный бухгалтер", "petrova@mail.ru", "8-925-555-55-55", 90000.00, 50);

        for (int i = 0; i < backOffice.length; i++){
            if (backOffice[i].age > 40) {
                backOffice[i].info();
            }
        }
    }
}


//
//        * С помощью цикла вывести информацию только о сотрудниках старше 40 лет;