package lesson5;

import java.util.Arrays;
import java.util.Random;

public class Forester {
    public static int treeRandom;
    public static int lengthTreeRandom;
    public static int lengthResult;

    public static void main(String[] args) {
        Random random = new Random();

        //Создаем пустой массив со всеми деревьями в лесу произвольной длинны
        lengthTreeRandom = random.nextInt(40);
        Integer[] tree = new Integer[lengthTreeRandom];

        /*
        Создаем пустой массив в каждый элемент которого
        будет записано количество сответствующего вида дерева
         */
        Integer[] count = new Integer[21];

        //Заполняем массив со всеми деревьями значениями и выводим его на экран
        for (int i = 0; i < tree.length; i++) {
            treeRandom = random.nextInt(20);
            tree[i] = treeRandom;
        }
        System.out.println("Во владениях лесника присутствуют следующие деревья: ");
        System.out.println(Arrays.toString(tree));
        System.out.println();

        //Записываем в каждый элемент массива количество сответствующего вида дерева
        for (int i = 0; i < tree.length; i++) {
            int a = tree[i];
            if (count[a] != null) {
                count[a]++;
            } else {
                count[a] = 1;
                lengthResult += 1;
            }
        }

        //Создаем результирующий массив только с не пустыми значениями
        Integer[] result = new Integer[lengthResult];
        int j = 0;

        //Заполняем результирующий массив только не пустыми значениями
        for (int i = 0; i < count.length; i++) {
            if (count[i] != null) {
                result[j] = count[i];
                j++;
            }
        }
        System.out.println("Подсчет. Сколько раз встречается каждый вид дерева: ");
        System.out.println(Arrays.toString(result));
    }
}

