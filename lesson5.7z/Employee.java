package lesson5;

public class Employee {
    String FIO;
    String position;
    String email;
    String phone;
    double salary;
    int age;

    public Employee(String FIO, String position, String email, String phone, double salary, int age) {
        this.FIO = FIO;
        this.position = position;
        this.email = email;
        this.phone = phone;
        this.salary = salary;
        this.age = age;
    }

    public Employee() {
    }

    public void info() {
        System.out.println("Данные по сотруднику:");
        System.out.println("ФИО: " + FIO);
        System.out.println("Должность: " + position);
        System.out.println("e-mail: " + email);
        System.out.println("Номер телефона: " + phone);
        System.out.println("Зарплата: " + salary);
        System.out.println("Возраст: " + age);
        System.out.println();
    }
}